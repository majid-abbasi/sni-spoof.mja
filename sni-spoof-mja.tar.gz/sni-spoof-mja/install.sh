#!/bin/bash

APP_NAME="sni-spoof-mja"
SRC_DIR="$(pwd)"
INSTALL_DIR="/opt/${APP_NAME}"
SERVICE_FILE="/etc/systemd/system/${APP_NAME}.service"
MANAGER_FILE="/usr/local/bin/mja"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

banner() {
    clear
    echo "======================================"
    echo "     LOCAL INSTALL SNI SPOOF MJA"
    echo "======================================"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "Run as root!"
        exit 1
    fi
}

install_packages() {

    if command -v apt >/dev/null 2>&1; then
        apt install -y nano
    elif command -v yum >/dev/null 2>&1; then
        yum install -y nano
    elif command -v dnf >/dev/null 2>&1; then
        dnf install -y nano
    fi
}

install_files() {

    echo "Copying files from: $SRC_DIR"
    mkdir -p "$INSTALL_DIR/backup"

    cp "$SRC_DIR/sni-spoof-mja" "$INSTALL_DIR/"
    cp "$SRC_DIR/config.json" "$INSTALL_DIR/"

    chmod +x "$INSTALL_DIR/sni-spoof-mja"
}

create_service() {

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=SNI Spoof MJA Service
After=network.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR
ExecStart=/bin/bash -c "cd $INSTALL_DIR && ./sni-spoof-mja"
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable $APP_NAME
    systemctl restart $APP_NAME
}

create_manager() {

cat > "$MANAGER_FILE" <<'EOF'
#!/bin/bash

APP="sni-spoof-mja"
DIR="/opt/sni-spoof-mja"
BACKUP="$DIR/backup"

mkdir -p "$BACKUP"

while true; do
clear

echo "======================"
echo "      MJA MENU"
echo "======================"
echo "1) Edit Config"
echo "2) Restart"
echo "3) Status"
echo "4) Logs"
echo "5) Backup Config"
echo "6) Restore Config"
echo "7) Remove"
echo "8) Exit"
echo ""

read -p "Select: " c

case $c in

1)
nano $DIR/config.json
;;

2)
systemctl restart $APP
;;

3)
systemctl status $APP
;;

4)
journalctl -u $APP -n 50 --no-pager
;;

5)
cp $DIR/config.json $BACKUP/config-$(date +%F-%H-%M-%S).json
echo "Backup done"
;;

6)
ls $BACKUP
echo ""
read -p "File: " f

cp "$BACKUP/$f" "$DIR/config.json"
systemctl restart $APP
;;

7)
systemctl stop $APP
systemctl disable $APP
rm -rf $DIR
rm -f /etc/systemd/system/$APP.service
rm -f /usr/local/bin/mja
systemctl daemon-reload
exit
;;

8)
exit
;;

esac

done
EOF

chmod +x "$MANAGER_FILE"
}

finish() {
    echo "======================================"
    echo " Installed Successfully (LOCAL MODE)"
    echo " Folder: /opt/sni-spoof-mja"
    echo " Run: mja"
    echo "======================================"
}

banner
check_root
install_packages
install_files
create_service
create_manager
finish